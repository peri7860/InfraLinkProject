package controler;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import service.EmployeeIdPreviewService;
import service.ChangePasswordService;
import service.Command;
import service.EmpRegisterService;
import service.EmployeeEditService;
import service.EmployeeListService;
import service.LoginService;
import service.UpdateMyInfoService;
import service.EmployeeIdPreviewService;
import service.EmployeeEditService;

@WebServlet("/pages/*")
public class pages extends HttpServlet {

	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doAction(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doAction(request, response);
	}

	protected void doAction(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");

		String action = request.getPathInfo();

		System.out.println("action : " + action);

		String page = null;

		switch (action) {

		// =========================
		// 로그인
		// =========================
		case "/loginpro.do":
			Command login = new LoginService();
			login.doCommand(request, response);
			return;

		// =========================
		// 내 정보 수정
		// =========================
		case "/updateMyInfo.do":
			Command updateMyInfo = new UpdateMyInfoService();
			updateMyInfo.doCommand(request, response);
			return;

		// =========================
		// 비밀번호 변경
		// =========================
		case "/changePassword.do":
			Command changePassword = new ChangePasswordService();
			changePassword.doCommand(request, response);
			return;

		// =========================
		// 사원 등록
		// =========================
		case "/employeeRegister.do":
			Command employeeRegister = new EmpRegisterService();
			employeeRegister.doCommand(request, response);
			return;

		case "/admin-employees.do":
			EmployeeListService employeeListService = new EmployeeListService();
			employeeListService.doCommand(request, response);
			return;

		case "/employeeIdPreview.do":
			EmployeeIdPreviewService employeeIdPreviewService = new EmployeeIdPreviewService();
			employeeIdPreviewService.doCommand(request, response);
			return;

		case "/admin-employee-edit.do":
			EmployeeEditService employeeEditService = new EmployeeEditService();
			employeeEditService.doCommand(request, response);
			return;
			
		// =========================
		// 단순 JSP 이동
		// =========================
		case "/approval.do":
			page = "/WEB-INF/pages/approval.jsp"; // 프로젝트 폴더 구조에 맞게 경로 수정
			break;
		case "/approval-rules.do":
			page = "/WEB-INF/pages/admin-approval-rules.jsp"; // 프로젝트 폴더 구조에 맞게 경로 수정
			break;
		case "/approval-write.do":
			page = "/WEB-INF/pages/approval-write.jsp";
			break;
		case "/approval-view.do":
			page = "/WEB-INF/pages/approval-view.jsp";
			break;
		case "/attendance.do":
			page = "/WEB-INF/pages/attendance.jsp";
			break;
		case "/admin-dashboard.do":
			page = "/WEB-INF/pages/admin-dashboard.jsp";
			break;
		case "/admin-activity.do":
			page = "/WEB-INF/pages/admin-activity.jsp";
			break;
		case "/admin-rules.do":
			page = "/WEB-INF/pages/admin-approval-rules.jsp";
			break;
		case "/admin-roles.do":
			page = "/WEB-INF/pages/admin-roles.jsp";
			break;
		case "/admin-role-edit.do":
			page = "/WEB-INF/pages/admin-role-edit.jsp";
			break;
		case "/admin-rule-edit.do":
			page = "/WEB-INF/pages/admin-approval-rule-edit.jsp";
			break;
		case "/board.do":
			page = "/WEB-INF/pages/board-list.jsp";
			break;
		case "/board-view.do":
			page = "/WEB-INF/pages/board-view.jsp";
			break;
		case "/board-write.do":
			page = "/WEB-INF/pages/board-write.jsp";
			break;
		case "/employee.do":
			page = "/WEB-INF/pages/employee-list.jsp";
			break;
		case "/employee-detail.do":
			page = "/WEB-INF/pages/employee-detail.jsp";
			break;
		case "/login.do":
			page = "/WEB-INF/pages/login.jsp";
			break;
		case "/password-reset.do":
			page = "/WEB-INF/pages/password-reset.jsp";
			break;
		case "/messenger.do":
			page = "/WEB-INF/pages/messenger.jsp";
			break;
		case "/mypage.do":
			page = "/WEB-INF/pages/mypage.jsp";
			break;
		case "/notice.do":
			page = "/WEB-INF/pages/notice-list.jsp";
			break;
		case "/notice-view.do":
			page = "/WEB-INF/pages/notice-view.jsp";
			break;
		case "/notice-write.do":
			page = "/WEB-INF/pages/notice-write.jsp";
			break;
		case "/room.do":
			page = "/WEB-INF/pages/room-reserve.jsp";
			break;
		case "/room-view.do":
			page = "/WEB-INF/pages/room-reserve-view.jsp";
			break;
		case "/room-write.do":
			page = "/WEB-INF/pages/room-reserve-write.jsp";
			break;
		case "/notifications.do":
			page = "/WEB-INF/pages/notifications.jsp";
			break;
		case "/schedule.do":
			// 비즈니스 로직(DB 저장 등) 처리 후 목록으로 이동
			page = "/WEB-INF/pages/schedule.jsp"; // 실제로는 DB 저장 후 목록 페이지로 리다이렉트
			break;
		case "/schedule-view.do":
			// 비즈니스 로직(DB 저장 등) 처리 후 목록으로 이동
			page = "/WEB-INF/pages/schedule-view.jsp"; // 실제로는 DB 저장 후 목록 페이지로 리다이렉트
			break;
		case "/schedule-write.do":
			// 비즈니스 로직(DB 저장 등) 처리 후 목록으로 이동
			page = "/WEB-INF/pages/schedule-write.jsp"; // 실제로는 DB 저장 후 목록 페이지로 리다이렉트
			break;
		case "/system-status.do":
			// 비즈니스 로직(DB 저장 등) 처리 후 목록으로 이동
			page = "/WEB-INF/pages/system-status.jsp"; // 실제로는 DB 저장 후 목록 페이지로 리다이렉트
			break;
		case "/index.do":
			page = "/webapp/index.jsp";
			break;

		default:
			response.sendError(HttpServletResponse.SC_NOT_FOUND);
			return;
		}

		request.getRequestDispatcher(page).forward(request, response);
	}
}
