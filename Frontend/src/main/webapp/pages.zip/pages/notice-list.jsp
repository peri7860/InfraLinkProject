<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
   
<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>お知らせ一覧 | InfraLink</title>

<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.3/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.11.3/font/bootstrap-icons.min.css">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Noto+Sans+JP:wght@400;500;600;700;800&display=swap" rel="stylesheet">

<link rel="stylesheet" href="../css/common.css">
<link rel="stylesheet" href="../css/header.css">
<link rel="stylesheet" href="../css/footer.css">
<link rel="stylesheet" href="../css/responsive.css">
</head>
<body data-page="notice">
<%@ include file="../components/header.jsp"%>
<%@ include file="../components/modal.jsp"%>
<div id="header-placeholder"></div>
<div id="modal-placeholder"></div>

<section class="sub-banner">
  <div class="container">
    <h1><i class="bi bi-megaphone"></i> お知らせ</h1>
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="../index.html">ホーム</a></li>
        <li class="breadcrumb-item active" aria-current="page">お知らせ</li>
      </ol>
    </nav>
  </div>
</section>

<div id="app-content">
  <div class="container content-wrap">
    <div class="row g-4">
      <aside class="col-lg-3"><div id="sidebar-placeholder"></div><%@ include file="../components/sidebar.jsp"%></aside>

      <section class="col-lg-9">
        <!-- ==================== 검색/필터 바 ==================== -->
        <div class="filter-bar">
          <select class="form-select form-select-sm" style="width:140px;">
            <option selected>全区分</option>
            <option>重要</option>
            <option>一般</option>
          </select>
          <select class="form-select form-select-sm" style="width:160px;">
            <option selected>全部署</option>
            <option>人事部</option>
            <option>総務部</option>
            <option>IT支援部</option>
          </select>
          <div class="input-group input-group-sm ms-auto" style="max-width:260px;">
            <input type="text" class="form-control" placeholder="タイトルを検索">
            <button class="btn btn-teal" type="button"><i class="bi bi-search"></i></button>
          </div>
        </div>

        <div class="panel">
          <div class="panel-header">
            <h5><i class="bi bi-list-ul"></i> お知らせ一覧</h5>
            <span class="text-muted" style="font-size:.8rem;">全 24件</span>
          </div>
          <div class="table-scroll">
            <table class="table list-table mb-0">
              <thead>
                <tr>
                  <th style="width:60px;" class="text-center">No</th>
                  <th style="width:80px;" class="text-center">区分</th>
                  <th>タイトル</th>
                  <th style="width:120px;" class="text-center">作成者</th>
                  <th style="width:110px;" class="text-center">登録日</th>
                  <th style="width:70px;" class="text-center">閲覧</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td class="text-center">24</td>
                  <td class="text-center"><span class="badge-fixed">重要</span></td>
                  <td><a href="notice-view.html?no=24" class="title-link">2026年 夏季休暇および勤務制度のご案内</a></td>
                  <td class="text-center">人事部</td>
                  <td class="text-center">2026.08.12</td>
                  <td class="text-center">312</td>
                </tr>
                <tr>
                  <td class="text-center">23</td>
                  <td class="text-center"><span class="badge-fixed">重要</span></td>
                  <td><a href="notice-view.html?no=23" class="title-link">社内システム定期点検のお知らせ（8/16 2:00〜5:00）</a></td>
                  <td class="text-center">IT支援部</td>
                  <td class="text-center">2026.08.11</td>
                  <td class="text-center">198</td>
                </tr>
                <tr>
                  <td class="text-center">22</td>
                  <td class="text-center"><span class="badge-normal">一般</span></td>
                  <td><a href="notice-view.html?no=22" class="title-link">第3四半期 社内サークル支援金申請のご案内</a></td>
                  <td class="text-center">総務部</td>
                  <td class="text-center">2026.08.10</td>
                  <td class="text-center">87</td>
                </tr>
                <tr>
                  <td class="text-center">21</td>
                  <td class="text-center"><span class="badge-normal">一般</span></td>
                  <td><a href="notice-view.html?no=21" class="title-link">新入社員オリエンテーション日程のお知らせ</a></td>
                  <td class="text-center">人事部</td>
                  <td class="text-center">2026.08.08</td>
                  <td class="text-center">150</td>
                </tr>
                <tr>
                  <td class="text-center">20</td>
                  <td class="text-center"><span class="badge-normal">一般</span></td>
                  <td><a href="notice-view.html?no=20" class="title-link">本社駐車場利用案内の変更事項</a></td>
                  <td class="text-center">総務部</td>
                  <td class="text-center">2026.08.07</td>
                  <td class="text-center">76</td>
                </tr>
                <tr>
                  <td class="text-center">19</td>
                  <td class="text-center"><span class="badge-normal">一般</span></td>
                  <td><a href="notice-view.html?no=19" class="title-link">社内食堂メニュー変更のお知らせ（9月分）</a></td>
                  <td class="text-center">総務部</td>
                  <td class="text-center">2026.08.05</td>
                  <td class="text-center">64</td>
                </tr>
                <tr>
                  <td class="text-center">18</td>
                  <td class="text-center"><span class="badge-normal">一般</span></td>
                  <td><a href="notice-view.html?no=18" class="title-link">社内セキュリティ研修（e-ラーニング）受講案内</a></td>
                  <td class="text-center">IT支援部</td>
                  <td class="text-center">2026.08.03</td>
                  <td class="text-center">203</td>
                </tr>
                <tr>
                  <td class="text-center">17</td>
                  <td class="text-center"><span class="badge-normal">一般</span></td>
                  <td><a href="notice-view.html?no=17" class="title-link">7月度 優秀社員表彰式のご案内</a></td>
                  <td class="text-center">人事部</td>
                  <td class="text-center">2026.07.30</td>
                  <td class="text-center">142</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        <div class="d-flex justify-content-between align-items-center mt-3">
          <a href="notice-write.html" class="btn btn-teal btn-sm"><i class="bi bi-pencil-square"></i> お知らせ作成</a>
        </div>

        <!-- ==================== 페이지네이션 ==================== -->
        <div class="pagination-wrap">
          <ul class="pagination">
            <li class="page-item disabled"><a class="page-link" href="#">前へ</a></li>
            <li class="page-item active"><a class="page-link" href="#">1</a></li>
            <li class="page-item"><a class="page-link" href="#">2</a></li>
            <li class="page-item"><a class="page-link" href="#">3</a></li>
            <li class="page-item"><a class="page-link" href="#">次へ</a></li>
          </ul>
        </div>
      </section>
    </div>
  </div>
</div>

<div id="footer-placeholder"></div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.3/js/bootstrap.bundle.min.js"></script>
<script src="../js/common.js"></script>
<script src="../js/notice.js"></script>
</body>
<%@ include file="../components/footer.jsp"%>
</html>
