<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
   
<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>掲示板 投稿 | InfraLink</title>

<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.3/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.11.3/font/bootstrap-icons.min.css">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Noto+Sans+JP:wght@400;500;600;700;800&display=swap" rel="stylesheet">

<link rel="stylesheet" href="../css/common.css">
<link rel="stylesheet" href="../css/header.css">
<link rel="stylesheet" href="../css/footer.css">
<link rel="stylesheet" href="../css/responsive.css">
</head>
<body data-page="board">

<div id="header-placeholder"></div>
<div id="modal-placeholder"></div>
<%@ include file="../components/header.jsp"%>
<%@ include file="../components/modal.jsp"%>
<section class="sub-banner">
  <div class="container">
    <h1><i class="bi bi-clipboard2-data"></i> 掲示板</h1>
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="../index.html">ホーム</a></li>
        <li class="breadcrumb-item"><a href="board-list.html">掲示板</a></li>
        <li class="breadcrumb-item active" aria-current="page">投稿</li>
      </ol>
    </nav>
  </div>
</section>

<div id="app-content">
  <div class="container content-wrap">
    <div class="row g-4">
      <aside class="col-lg-3"><div id="sidebar-placeholder"></div><%@ include file="../components/sidebar.jsp"%></aside>

      <section class="col-lg-9">
        <div class="panel">
          <div class="panel-header">
            <h5><i class="bi bi-pencil-square"></i> 掲示板 投稿</h5>
          </div>

          <form class="form-panel" id="boardWriteForm">
            <div class="row g-3 mb-3">
              <div class="col-md-6">
                <label class="form-label">掲示板の種類</label>
                <select class="form-select">
                  <option>自由掲示板</option>
                  <option>情報共有</option>
                  <option>中古売買</option>
                  <option>Q&amp;A</option>
                </select>
              </div>
              <div class="col-md-6">
                <label class="form-label">公開範囲</label>
                <select class="form-select">
                  <option>全社員に公開</option>
                  <option>所属部署のみ</option>
                </select>
              </div>
            </div>

            <div class="mb-3">
              <label class="form-label" for="boardTitle">タイトル <span class="text-danger">*</span></label>
              <input type="text" class="form-control" id="boardTitle" placeholder="タイトルを入力してください">
            </div>

            <div class="mb-3">
              <label class="form-label" for="boardContent">内容 <span class="text-danger">*</span></label>
              <textarea class="form-control" id="boardContent" rows="10" placeholder="内容を入力してください"></textarea>
            </div>

            <div class="mb-3">
              <label class="form-label">画像・添付ファイル</label>
              <input type="file" class="form-control" multiple>
            </div>

            <div class="form-check">
              <input class="form-check-input" type="checkbox" id="boardAnonymous">
              <label class="form-check-label small" for="boardAnonymous">匿名で投稿する</label>
            </div>

            <div class="form-actions">
              <a href="board-list.html" class="btn btn-outline-secondary px-4">キャンセル</a>
              <button type="submit" class="btn btn-teal px-4">投稿する</button>
            </div>
          </form>
        </div>
      </section>
    </div>
  </div>
</div>

<div id="footer-placeholder"></div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.3/js/bootstrap.bundle.min.js"></script>
<script src="../js/common.js"></script>
<script src="../js/board.js"></script>
</body>
<%@ include file="../components/footer.jsp"%>
</html>
