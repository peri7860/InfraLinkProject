<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
   
<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>マイページ | InfraLink</title>

<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.3/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.11.3/font/bootstrap-icons.min.css">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Noto+Sans+JP:wght@400;500;600;700;800&display=swap" rel="stylesheet">

<link rel="stylesheet" href="../css/common.css">
<link rel="stylesheet" href="../css/header.css">
<link rel="stylesheet" href="../css/footer.css">
<link rel="stylesheet" href="../css/responsive.css">
</head>
<body data-page="mypage">
<%@ include file="../components/header.jsp"%>
<%@ include file="../components/modal.jsp"%>
<div id="header-placeholder"></div>
<div id="modal-placeholder"></div>

<section class="sub-banner">
  <div class="container">
    <h1><i class="bi bi-person-gear"></i> マイページ</h1>
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="../index.html">ホーム</a></li>
        <li class="breadcrumb-item active" aria-current="page">マイページ</li>
      </ol>
    </nav>
  </div>
</section>

<div id="app-content">
  <div class="container content-wrap">
    <div class="row g-4">
      <aside class="col-lg-3"><div id="sidebar-placeholder"></div><%@ include file="../components/sidebar.jsp"%></aside>

      <section class="col-lg-9">
        <div class="row g-4">
          <!-- ==================== 프로필 요약 ==================== -->
          <div class="col-md-4">
            <div class="panel text-center p-4">
              <div class="employee-card avatar" style="width:96px;height:96px;font-size:2rem;">山</div>
              <h5 class="mt-3 mb-0">山田 太郎</h5>
              <p class="text-muted small mb-2">経営企画部 ・ 部長</p>
              <button class="btn btn-outline-teal btn-sm w-100"><i class="bi bi-camera"></i> 写真を変更</button>
            </div>

            <div class="panel widget">
              <div class="panel-header">
                <h5><i class="bi bi-bar-chart"></i> 今月の勤怠サマリー</h5>
              </div>
              <div class="panel-body">
                <table class="table table-borderless table-sm mb-0" style="font-size:.85rem;">
                  <tbody>
                    <tr><td class="text-muted">出勤日数</td><td class="text-end fw-bold">11日</td></tr>
                    <tr><td class="text-muted">残り年次休暇</td><td class="text-end fw-bold text-teal">8.5日</td></tr>
                    <tr><td class="text-muted">決裁待ち文書</td><td class="text-end fw-bold">3件</td></tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          <!-- ==================== 정보 수정 폼 ==================== -->
          <div class="col-md-8">
            <div class="panel">
              <div class="panel-header">
                <h5><i class="bi bi-person-lines-fill"></i> 個人情報</h5>
              </div>
              <form class="form-panel">
                <div class="row g-3">
                  <div class="col-md-6">
                    <label class="form-label">氏名</label>
                    <input type="text" class="form-control" value="山田 太郎" disabled>
                  </div>
                  <div class="col-md-6">
                    <label class="form-label">社員番号</label>
                    <input type="text" class="form-control" value="PLN-2016-002" disabled>
                  </div>
                  <div class="col-md-6">
                    <label class="form-label">連絡先（内線）</label>
                    <input type="text" class="form-control" value="101">
                  </div>
                  <div class="col-md-6">
                    <label class="form-label">携帯電話番号</label>
                    <input type="text" class="form-control" value="090-0000-0000">
                  </div>
                  <div class="col-12">
                    <label class="form-label">メールアドレス</label>
                    <input type="email" class="form-control" value="t.yamada@infralink.co.jp">
                  </div>
                </div>
                <div class="form-actions justify-content-end">
                  <button type="submit" class="btn btn-teal px-4">保存する</button>
                </div>
              </form>
            </div>

            <div class="panel mt-4">
              <div class="panel-header">
                <h5><i class="bi bi-shield-lock"></i> パスワード変更</h5>
              </div>
              <form class="form-panel">
                <div class="mb-3">
                  <label class="form-label">現在のパスワード</label>
                  <input type="password" class="form-control" placeholder="現在のパスワードを入力してください">
                </div>
                <div class="row g-3">
                  <div class="col-md-6">
                    <label class="form-label">新しいパスワード</label>
                    <input type="password" class="form-control" placeholder="新しいパスワードを入力してください">
                  </div>
                  <div class="col-md-6">
                    <label class="form-label">新しいパスワード（確認）</label>
                    <input type="password" class="form-control" placeholder="もう一度入力してください">
                  </div>
                </div>
                <div class="form-actions justify-content-end">
                  <button type="submit" class="btn btn-outline-teal px-4">変更する</button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </section>
    </div>
  </div>
</div>

<div id="footer-placeholder"></div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.3/js/bootstrap.bundle.min.js"></script>
<script src="../js/common.js"></script>
</body>
<%@ include file="../components/footer.jsp"%>
</html>
